// script.js
const audioPlayer = document.getElementById('audioPlayer');
const fileInput = document.getElementById('fileInput');

fileInput.addEventListener('change', function() {
  const file = fileInput.files[0];
  if (file) {
    audioPlayer.src = URL.createObjectURL(file);
    audioPlayer.load();
  }
});
// script.js
const playButton = document.createElement('button');
playButton.textContent = 'Reproducir';
document.getElementById('music-player').appendChild(playButton);

playButton.addEventListener('click', function() {
  audioPlayer.play();
});
// script.js
const pauseButton = document.createElement('button');
pauseButton.textContent = 'Pausar';
document.getElementById('music-player').appendChild(pauseButton);

pauseButton.addEventListener('click', function() {
  if (audioPlayer.paused) {
    audioPlayer.play();
  } else {
    audioPlayer.pause();
  }
});
// script.js
const progressContainer = document.getElementById('progressContainer');

audioPlayer.addEventListener('timeupdate', function() {
  const currentTime = audioPlayer.currentTime;
  const totalTime = audioPlayer.duration;
  const progress = (currentTime / totalTime) * 100;
  progressContainer.textContent = `${Math.floor(progress)}%`;
});
// script.js
audioPlayer.addEventListener('ended', function() {
  console.log('Archivo reproducido con éxito!');
});
// script.js
audioPlayer.addEventListener('error', function() {
  console.error('Error al reproducir el archivo MP3');
});